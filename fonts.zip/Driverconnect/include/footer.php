<footer class="footer-section">
        <div class="copyright-reserved">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright-text">
Copyright &copy; Driver Connect <?php echo date('Y');?>
                        </div>
                      
                    </div>
                </div>
            </div>
        </div>
    </footer>